package Control;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.swing.text.DefaultEditorKit.BeepAction;

import Model.DataBase.TabelaDonoVeiculo;
import View.Interface;

public class Main {
	public static void main(String[] args) throws MalformedURLException, IOException {
		
		

		new Interface();
	
		

		
	}
}
