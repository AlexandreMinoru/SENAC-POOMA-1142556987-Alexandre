package Model.DataBase;

import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;


import Control.BancoDados;
import Model.General.DonoVeiculo;
import Model.General.Veiculo;

public class TabelaVeiculo extends ConectarBanco {

	public TabelaVeiculo() {
		// TODO Auto-generated constructor stub
	}
	
	public void adicionarVeiculo(String modelo, String placa, String dono, String cor) { 
		try {
			BancoDados banco = new BancoDados();
			Connection cn = super.getCon();
			PreparedStatement ps = cn.prepareStatement(
					"INSERT INTO veiculo (placa, cor, modelo, dono)"
							+ "VALUES (?, ?, ?, ?)");            
			ps.setString(3, modelo);
			ps.setString(1, 
					placa);
			ps.setString(2, cor);
			ps.setInt(4, banco.pesquisarDonoVeiculoNome(dono).getId());
			ps.executeUpdate();
			JOptionPane.showMessageDialog(null, "Veículo cadastrado com sucesso.");
			ps.close();   
			
			System.out.println("ConexÃ£o encerrada.");            
		} catch (SQLException e) {
			System.out.println("Falha ao realizar a operaÃ§Ã£o.");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    
	}
	
	public void editarVeiculo() {
		
	}
	
	public Veiculo pesquisarVeiculo(int i) throws java.lang.Exception {
		Veiculo veiculo = null;
		BancoDados banco = new BancoDados();
		String queryCmd = "select * from veiculo where "
				+ "id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {				
				int id = rs.getInt("id");
				String placa = rs.getString("placa");
				String cor = rs.getString("cor");
				String modelo = rs.getString("modelo");	
				DonoVeiculo dono = banco.pesquisarDonoVeiculo(rs.getInt("dono"));
				try {
					dono = banco.pesquisarDonoVeiculo(rs.getInt("dono"));
					veiculo = new Veiculo(id,modelo,placa,cor,dono);
				} catch (java.lang.Exception e) {
					e.printStackTrace();
					return null;
				}
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return veiculo;
	}
	
	
	
	public ArrayList<Veiculo> listaVeiculos(int i ) throws Exception{
		BancoDados banco = new BancoDados();
		ArrayList<Veiculo> listaVeiculos = new ArrayList<Veiculo>();
		String queryCmd = "select * from veiculo where "
				+ "dono like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			while(rs.next()) {		
				
				int id = rs.getInt("id");
				String placa = rs.getString("placa");
				String cor = rs.getString("cor");
				String modelo = rs.getString("modelo");	
				DonoVeiculo dono = null;
				try {
					dono = banco.pesquisarDonoVeiculoNoConnection(rs.getInt("dono"));
					listaVeiculos.add(new Veiculo(id,modelo,placa,cor,dono));
				} catch (java.lang.Exception e) {
					e.printStackTrace();
				}	
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		}	
		return listaVeiculos;
	}
	
	public ArrayList<Veiculo> listaTodosVeiculos()  throws Exception{
		BancoDados banco = new BancoDados();
		ArrayList<Veiculo> listaVeiculos = new ArrayList<Veiculo>();
		String queryCmd = "select * from veiculo";				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			while(rs.next()) {		
				
				int id = rs.getInt("id");
				String placa = rs.getString("placa");
				String cor = rs.getString("cor");
				String modelo = rs.getString("modelo");	
				DonoVeiculo dono = banco.pesquisarDonoVeiculo(rs.getInt("dono"));
				try {
					dono = banco.pesquisarDonoVeiculoNoConnection(rs.getInt("dono"));
					listaVeiculos.add(new Veiculo(id,modelo,placa,cor,dono));
				} catch (java.lang.Exception e) {
					e.printStackTrace();
				}	
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		}	
		return listaVeiculos;
	}
	
	
	public Veiculo pesquisarVeiculoModelo(String nome) throws Exception {
		ArrayList<Veiculo> lista = new ArrayList<Veiculo>();
		BancoDados banco = new BancoDados();
		Veiculo dono = null;
		String queryCmd = "select * from veiculo where "
				+ "modelo like '" + nome +"'";				
		try {
			
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();		
			

			while(rs.next()) {		
				Veiculo teste = new Veiculo();
				teste = new Veiculo();
				teste.setId(rs.getInt("id"));
				teste.setModelo(rs.getString("modelo"));
				teste.setPlaca(rs.getString("placa"));
				teste.setCor(rs.getString("cor"));
				teste.setDono(banco.pesquisarDonoVeiculo(rs.getInt("dono")));
				lista.add(teste);
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
			if(lista.size() >= 1) {
				dono = lista.get(Integer.parseInt(JOptionPane.showInputDialog(listarVeiculosRepetidos(lista))) -1);
			}
			
			if(dono == null) {
				JOptionPane.showMessageDialog(null, "Veiculo não existe");

			}
		return dono;
	}
	
public String listarVeiculosRepetidos(ArrayList<Veiculo> lista) {
		
		StringBuilder builder = new StringBuilder();
		
		builder.append("Lista de Veículos: \n");
		
		for (int i = 0; i < lista.size(); i++) {
			builder.append("["+(i + 1)+"] " + lista.get(i).getModelo() + " Placa:  " + lista.get(i).getPlaca() + " Dono: "+ lista.get(i).getDono().getNome() + "\n");
		}
		return builder.toString();
	}

public void editarVeiculo(int id, String novaPlaca, String novaCor, String novoModelo, String novoDonoId) throws Exception {
    try {
    	BancoDados banco = new BancoDados();
        Connection cn = super.getCon();
        String editarVeiculo = "UPDATE veiculo SET placa = ?, cor = ?, modelo = ?, dono = ? WHERE id = ?";
        PreparedStatement psEditar = cn.prepareStatement(editarVeiculo);
        psEditar.setString(1, novaPlaca);
        psEditar.setString(2, novaCor);
        psEditar.setString(3, novoModelo);
        psEditar.setInt(4, banco.pesquisarDonoVeiculoNome(novoDonoId).getId());
        psEditar.setInt(5, id);

        int linhasAfetadas = psEditar.executeUpdate();
        psEditar.close();

       JOptionPane.showMessageDialog(null, "Veiculo alterado com sucesso");
    } catch (SQLException e) {
        throw new Exception(e);
    }
}

public void removerVeiculo(int id) throws Exception {
    try {
        Connection cn = super.getCon();
        String removerVeiculo = "DELETE FROM veiculo WHERE id = ?";
        PreparedStatement psRemover = cn.prepareStatement(removerVeiculo);
        psRemover.setInt(1, id);

        int linhasAfetadas = psRemover.executeUpdate();
        psRemover.close();

        

    } catch (SQLException e) {
        throw new Exception(e);
    }
}
}
