package Model.DataBase;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Model.General.Abastecimento;
import Model.General.DonoVeiculo;
import Model.General.Posto;
import Model.General.Veiculo;

public class TabelaAbastecimento extends TabelaPosto{
	
	
	
	
	public Double calcularMediaKm( double kmAtual, double quantidadeAbastecida) {

		return kmAtual/ quantidadeAbastecida;
	}
	
	
	
	
	public Double buscarPrecoGasolina(int i) throws Exception {
		String queryCmd = "select * from tipogasolina where id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				return rs.getDouble("valor");
				
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return null;
	}
	
	
	public String buscarNomeGasolina(int i) throws Exception {
		String queryCmd = "select * from tipogasolina where id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				return rs.getNString("nome");
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return null;
	}
	
	
	public Double encontrarAbastecimentoAnteriorKm( int i) throws Exception {
		Double anterior = null;
		String queryCmd = "SELECT mediaKM FROM abastecimento where veiculo like " + i;		
		try {

			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				return rs.getDouble("mediaKM");
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return null;
	}
	
	
	
	public Double calcularQuantidade(Double valorTotal, Double valorGasolina) {
		return valorTotal / valorGasolina;
	}
	
	public Abastecimento buscarAbastecimento(int i) throws Exception {
		Abastecimento abastecimento = null;
		String queryCmd = "select * from abastecimento where "
				+ "id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				abastecimento = new Abastecimento();
				abastecimento.setId(rs.getInt("id"));
				abastecimento.setResponsavel(super.pesquisarDonoVeiculo(rs.getInt("responsavel")));
				abastecimento.setVeiculo(pesquisarVeiculo(rs.getInt("veiculo")));
				abastecimento.setPosto(pesquisarPosto(rs.getInt("posto")));
				abastecimento.setTipoCombustivel(buscarNomeGasolina(rs.getInt("tipoGasolina")));
				abastecimento.setQuantidade(rs.getDouble("quantidade"));	
				abastecimento.setPreco(rs.getDouble("valor"));
				abastecimento.setKmViajados(rs.getDouble("kmViajados"));
				abastecimento.setMediaKm(rs.getDouble("mediaKM"));
				abastecimento.setData(rs.getString("data"));
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 
		return abastecimento;
	}
	
	public ArrayList<Abastecimento> listarAbastecimentos() throws Exception {
		ArrayList<Abastecimento> listaAbastecimentos = new ArrayList<Abastecimento>();
		String queryCmd = "select * from abastecimento";		
		try {
			
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			while(rs.next()) {		
				Abastecimento abastecimento = null;
				abastecimento = new Abastecimento();
				abastecimento.setId(rs.getInt("id"));
				abastecimento.setResponsavel(super.pesquisarDonoVeiculo(rs.getInt("responsavel")));
				abastecimento.setVeiculo(pesquisarVeiculo(rs.getInt("veiculo")));
				abastecimento.setPosto(pesquisarPosto(rs.getInt("posto")));
				abastecimento.setTipoCombustivel(buscarNomeGasolina(rs.getInt("tipoGasolina")));
				abastecimento.setQuantidade(rs.getDouble("quantidade"));	
				abastecimento.setPreco(rs.getDouble("valor"));
				abastecimento.setKmViajados(rs.getDouble("kmViajados"));
				abastecimento.setMediaKm(rs.getDouble("mediaKM"));
				abastecimento.setData(rs.getString("data"));
				listaAbastecimentos.add(abastecimento);
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 
		return listaAbastecimentos;
	}
	
	
	
	public void adicionarAbastecimento( String responsavel, String veiculo, String posto, int tipoCombustivel, double quantidadeViajada, double valor, String data) throws Exception {
		try {
			super.openDB();
			Connection cn = super.getCon();
			PreparedStatement ps = cn.prepareStatement(
					"INSERT INTO abastecimento (responsavel, veiculo,  posto, valor,quantidade, tipoGasolina,kmViajados, mediaKM, data)"
							+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");     
			double valorGasolina = this.buscarPrecoGasolina(tipoCombustivel);
			 int id = super.pesquisarVeiculoModelo(veiculo).getId();
			double kmAnterior = this.encontrarAbastecimentoAnteriorKm(id);
			ps.setInt(1,super.pesquisarDonoVeiculoNome(responsavel).getId());
			ps.setInt(2, id);
			ps.setInt(3,super.pesquisarPostoMarca(posto).getId());
			ps.setDouble(4, valor);
			ps.setDouble(5, this.calcularQuantidade(valor, valorGasolina));
			ps.setInt(6, tipoCombustivel);
			ps.setDouble(7, quantidadeViajada);
			ps.setDouble(8, calcularMediaKm( quantidadeViajada, valorGasolina));
			ps.setString(9, data);
			
			
			ps.executeUpdate();
			ps.close();   
			double antigo = this.encontrarAbastecimentoAnteriorKm(super.pesquisarVeiculoModelo(veiculo).getId());
			double porcento = antigo * 0.2;
			antigo -= porcento;
			if(calcularMediaKm( quantidadeViajada, valorGasolina) < antigo) {
				JOptionPane.showMessageDialog(null, "Média menor que 20% em relação aos anteriores. \n"
						+ "Recomendado uma revisão no veículo");
			}
		} catch (SQLException e) {
			System.out.println("Falha ao realizar a operaÃ§Ã£o.");
			e.printStackTrace();
		}    
	}
	
	public void editarAbastecimento(int id, String responsavel, String veiculo, String posto, int tipoCombustivel, double quantidadeViajada, double valor, String data) throws Exception {
	    try {
	        Connection cn = super.getCon();
	        // Consulta para obter informações necessárias para o cálculo da média
	        double valorGasolina = this.buscarPrecoGasolina(tipoCombustivel);
			 int idCarro = super.pesquisarVeiculoModelo(veiculo).getId();

	        // Consulta para atualizar o abastecimento
	        String atualizarAbastecimento = "UPDATE abastecimento SET responsavel = ?, veiculo = ?, posto = ?, tipoGasolina = ?, quantidade = ?, valor = ?, kmViajados = ?, mediaKM = ?, data = ? WHERE id = ? ";
	        PreparedStatement psAtualizar = cn.prepareStatement(atualizarAbastecimento);
	        psAtualizar.setInt(1, super.pesquisarDonoVeiculoNome(responsavel).getId());
	        psAtualizar.setInt(2, idCarro);
	        psAtualizar.setInt(3, super.pesquisarPostoMarca(posto).getId());
	        psAtualizar.setInt(4, tipoCombustivel); 
	        psAtualizar.setDouble(5, this.calcularQuantidade(valor, valorGasolina));
	        psAtualizar.setDouble(6, valor);
	        psAtualizar.setDouble(7, quantidadeViajada);
	        psAtualizar.setDouble(8, calcularMediaKm( quantidadeViajada, valorGasolina));
	        psAtualizar.setString(9, data);
	        psAtualizar.setInt(10, id);

	        psAtualizar.executeUpdate();
	        psAtualizar.close();
	        JOptionPane.showMessageDialog(null, "Abastecimento atualizado com sucesso");
	    } catch (SQLException e) {
	        throw new Exception(e);
	    }
	    
	} 
	    public void excluirAbastecimento(int id) throws Exception {
	        try {
	            Connection cn = super.getCon();
	            // Consulta para obter informações necessárias antes de excluir
	            String consultaAnterior = "SELECT veiculo, data FROM abastecimento WHERE id = ?";
	            PreparedStatement psConsulta = cn.prepareStatement(consultaAnterior);
	            psConsulta.setInt(1, id);
	            ResultSet rsConsulta = psConsulta.executeQuery();

	            if (rsConsulta.next()) {
	                rsConsulta.getInt("veiculo");
	            } else {
	                throw new Exception("Abastecimento não encontrado.");
	            }
	            psConsulta.close();

	            // Consulta para excluir o abastecimento
	            String excluirAbastecimento = "DELETE FROM abastecimento WHERE id = ?";
	            PreparedStatement psExcluir = cn.prepareStatement(excluirAbastecimento);
	            psExcluir.setInt(1, id);

	            int linhasAfetadas = psExcluir.executeUpdate();
	            psExcluir.close();

	            if (linhasAfetadas > 0) {
	                // Atualizar outros dados ou realizar ações necessárias após a exclusão
	                // ...
	                System.out.println("Abastecimento removido com sucesso!");
	            } else {
	                System.out.println("Nenhum abastecimento removido. Verifique o ID.");
	            }

	        } catch (SQLException e) {
	            throw new Exception(e);
	        }
	    }
}




