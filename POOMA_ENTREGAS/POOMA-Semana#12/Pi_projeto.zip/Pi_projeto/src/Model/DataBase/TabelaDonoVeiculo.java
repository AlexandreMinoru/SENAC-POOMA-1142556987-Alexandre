package Model.DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Model.General.DonoVeiculo;
import Model.General.Veiculo;

public class TabelaDonoVeiculo  extends TabelaVeiculo{
	
	public void adicionarDonoVeiculo(String nome, int idade, String telefone, String cpf, int setor) { 
		try {
			super.openDB();
			Connection cn = super.getCon();
			PreparedStatement ps = cn.prepareStatement(
					"INSERT INTO DonoVeiculo (nome, idade, telefone, cpf, fk_setor)"
							+ "VALUES (?, ?, ?, ?, ?)");            
			ps.setString(1, nome);
			ps.setInt(2, idade);
			ps.setString(3, telefone);
			ps.setString(4, cpf);
			ps.setInt(5, setor);
			ps.executeUpdate();
			JOptionPane.showMessageDialog(null, "Funcionario cadastrado com sucesso.");
			
			
			System.out.println("ConexÃ£o encerrada.");            
		} catch (SQLException e) {
			System.out.println("Falha ao realizar a operaÃ§Ã£o.");
			e.printStackTrace();
		}    
	}
	
	
	public DonoVeiculo pesquisarDonoVeiculo(int i) throws Exception {
		DonoVeiculo dono = null;
		String queryCmd = "select * from DonoVeiculo where "
				+ "id like " + i;				
		try {
			super.openDB();
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				dono = new DonoVeiculo();
				dono.setId(rs.getInt("id"));
				dono.setNome(rs.getString("nome"));
				dono.setCpf(rs.getString("cpf"));
				dono.setTelefone(rs.getString("telefone"));
				dono.setIdade(rs.getInt("idade"));
				dono.setSetor(this.pesquisarSetor(rs.getInt("fk_setor")));	
				dono.setVeiculos(super.listaVeiculos(dono.getId()));
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
			
		return dono;
	}
	
	
	public ArrayList<DonoVeiculo> listarDonoVeiculo() throws Exception {
		ArrayList<DonoVeiculo> listaDonoVeiculos = new ArrayList<>();
		DonoVeiculo dono = null;
		String queryCmd = "select * from gerenciamentoabastecimento.DonoVeiculo ";				
		try {
			
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			while(rs.next()) {		
				dono = new DonoVeiculo();
				dono.setId(rs.getInt("id"));
				dono.setNome(rs.getString("nome"));
				dono.setCpf(rs.getString("cpf"));
				dono.setTelefone(rs.getString("telefone"));
				dono.setIdade(rs.getInt("idade"));
				dono.setSetor(this.pesquisarSetor(rs.getInt("fk_setor")));	
				dono.setVeiculos(super.listaVeiculos(dono.getId()));
				listaDonoVeiculos.add(dono);
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 
		
		return listaDonoVeiculos;
	}
	
	public String pesquisarSetor(int i) throws Exception {
		String queryCmd = "select * from setor where "
				+ "id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {				
				return rs.getString("nome");
							
			}
			
		} catch (SQLException e) {
			throw new Exception(e);
		}
		return null;
	}
	
	public DonoVeiculo pesquisarDonoVeiculoNoConnection(int i) throws Exception {
		DonoVeiculo dono = null;
		String queryCmd = "select * from DonoVeiculo where "
				+ "id like " + i;				
		try {

			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				dono = new DonoVeiculo();
				dono.setId(rs.getInt("id"));
				dono.setNome(rs.getString("nome"));
				dono.setCpf(rs.getString("cpf"));
				dono.setTelefone(rs.getString("telefone"));
				dono.setIdade(rs.getInt("idade"));
				dono.setSetor(this.pesquisarSetor(rs.getInt("fk_setor")));	
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 
		return dono;
	}
	
	public DonoVeiculo pesquisarDonoVeiculoNome(String nome) throws Exception {
		ArrayList<DonoVeiculo> lista = new ArrayList<DonoVeiculo>();
		DonoVeiculo dono = null;
		String queryCmd = "select * from DonoVeiculo where "
				+ "nome like '" + nome +"'";				
		try {
			super.openDB();
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();		
			

			while(rs.next()) {		
				DonoVeiculo teste = new DonoVeiculo();
				teste = new DonoVeiculo();
				teste.setId(rs.getInt("id"));
				teste.setNome(rs.getString("nome"));
				teste.setCpf(rs.getString("cpf"));
				teste.setTelefone(rs.getString("telefone"));
				teste.setIdade(rs.getInt("idade"));
				teste.setSetor(this.pesquisarSetor(rs.getInt("fk_setor")));	
				teste.setVeiculos(super.listaVeiculos(teste.getId()));
				lista.add(teste);
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
			if(lista.size() >= 1) {
				dono = lista.get(Integer.parseInt(JOptionPane.showInputDialog(listarDonosRepetidos(lista))) -1);
			}
			
			if(dono == null) {
				JOptionPane.showMessageDialog(null, "Funcionário não existe");

			}
		return dono;
	}
	
		
	public String listarDonosRepetidos(ArrayList<DonoVeiculo> lista) {
		
		StringBuilder builder = new StringBuilder();
		
		builder.append("Lista de funcionários: \n");
		
		for (int i = 0; i < lista.size(); i++) {
			builder.append("["+(i + 1)+"] " + lista.get(i).getNome() + " CPF:  " + lista.get(i).getCpf() + " Setor: "+ lista.get(i).getSetor() + "\n");
		}
		return builder.toString();
	}
	
	public String listarSetor() throws Exception {
		String queryCmd = "select * from setor i";				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {				
				return rs.getString("nome");
							
			}
			
		} catch (SQLException e) {
			throw new Exception(e);
		}
		return null;
	}
	
	public void editarDonoVeiculo(int id, String novoNome, int novaIdade, String novoTelefone, String novoCpf, int novoSetorId) throws Exception {
	    try {
	        Connection cn = super.getCon();
	        String editarDonoVeiculo = "UPDATE DonoVeiculo SET nome = ?, idade = ?, telefone = ?, cpf = ?, fk_setor = ? WHERE id = ?";
	        PreparedStatement psEditar = cn.prepareStatement(editarDonoVeiculo);

	        psEditar.setString(1, novoNome);
	        psEditar.setInt(2, novaIdade);
	        psEditar.setString(3, novoTelefone);
	        psEditar.setString(4, novoCpf);
	        psEditar.setInt(5, novoSetorId);
	        psEditar.setInt(6, id);

	        int linhasAfetadas = psEditar.executeUpdate();
	        psEditar.close();

	        JOptionPane.showMessageDialog(null, "Funcionário alterado com sucesso");

	    } catch (SQLException e) {
	        throw new Exception(e);
	    }
	}
	
	
	
	public void removerDonoVeiculo(int id) throws Exception {
	    try {
	        Connection cn = super.getCon();
	        String removerDonoVeiculo = "DELETE FROM DonoVeiculo WHERE id = ?";
	        PreparedStatement psRemover = cn.prepareStatement(removerDonoVeiculo);
	        psRemover.setInt(1, id);

	        int linhasAfetadas = psRemover.executeUpdate();
	        psRemover.close();

	        if (linhasAfetadas > 0) {
	            System.out.println("DonoVeiculo removido com sucesso!");
	        } else {
	            System.out.println("Nenhum DonoVeiculo removido. Verifique o ID.");
	        }

	    } catch (SQLException e) {
	        throw new Exception(e);
	    }
	}
}


