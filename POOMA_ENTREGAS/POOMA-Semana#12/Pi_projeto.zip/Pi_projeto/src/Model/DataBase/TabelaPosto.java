package Model.DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Control.BancoDados;
import Model.General.DonoVeiculo;
import Model.General.Posto;
import Model.General.Veiculo;

public class TabelaPosto extends TabelaDonoVeiculo {
	
	
	public void adicionarPosto(String endereco, String marca) {
		try {
			Connection cn = super.getCon();
			PreparedStatement ps = cn.prepareStatement(
					"INSERT INTO posto (endereco, marca)"
							+ "VALUES (?, ?)");            
			ps.setString(1, endereco);
			ps.setString(2, 
					marca);
			ps.executeUpdate();
			JOptionPane.showMessageDialog(null, "Posto cadastrado com sucesso");
			ps.close();   
			
			System.out.println("ConexÃ£o encerrada.");            
		} catch (SQLException e) {
			System.out.println("Falha ao realizar a operaÃ§Ã£o.");
			e.printStackTrace();
		}    
	}
	
	public Posto pesquisarPosto(int i) throws Exception {
		Posto posto = null;
		String queryCmd = "select * from posto where "
				+ "id like " + i;				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {		
				posto = new Posto();
				posto.setId(rs.getInt("id"));
				posto.setMarca(rs.getString("marca"));
				posto.setLocalizacao(rs.getString("endereco"));
				
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return posto;
	}
	public ArrayList<Posto> listarPostos() throws Exception {
		ArrayList<Posto> listaPostos = new ArrayList<Posto>();
		String queryCmd = "select * from posto";				
		try {
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();			
			while(rs.next()) {		
				Posto posto = new Posto();
				posto.setId(rs.getInt("id"));
				posto.setMarca(rs.getString("marca"));
				posto.setLocalizacao(rs.getString("endereco"));
				
				listaPostos.add(posto);
				
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
		return listaPostos;
	}
	
	public Posto pesquisarPostoMarca(String nome) throws Exception {
		ArrayList<Posto> lista = new ArrayList<Posto>();
		BancoDados banco = new BancoDados();
		Posto dono = null;
		String queryCmd = "select * from posto where "
				+ "marca like '" + nome +"'";				
		try {
			super.openDB();
			Connection con = super.getCon();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ResultSet rs = ps1.executeQuery();		
			

			while(rs.next()) {		
				Posto teste = new Posto();
				teste = new Posto();
				teste.setId(rs.getInt("id"));
				teste.setMarca(rs.getString("marca"));
				teste.setLocalizacao(rs.getString("endereco"));
				
				lista.add(teste);
			}
		} catch (SQLException e) {
			throw new Exception(e); 
		} 	
			if(lista.size() >= 1) {
				dono = lista.get(Integer.parseInt(JOptionPane.showInputDialog(listarPostosRepetidos(lista))) -1);
			}
			
			if(dono == null) {
				JOptionPane.showMessageDialog(null, "Posto não existe");

			}
		return dono;
	}
	
public String listarPostosRepetidos(ArrayList<Posto> lista) {
		
		StringBuilder builder = new StringBuilder();
		
		builder.append("Lista de Postos: \n");
		
		for (int i = 0; i < lista.size(); i++) {
			builder.append("["+(i + 1)+"] " + lista.get(i).getMarca() + " Endereço  " + lista.get(i).getLocalizacao() + "\n");
		}
		return builder.toString();
	}

public void editarPosto(int id, String novoEndereco, String novaMarca) throws Exception {
    try {
        Connection cn = super.getCon();
        String atualizarPosto = "UPDATE posto SET endereco = ?, marca = ? WHERE id = ?";
        PreparedStatement psAtualizar = cn.prepareStatement(atualizarPosto);
        psAtualizar.setString(1, novoEndereco);
        psAtualizar.setString(2, novaMarca);
        psAtualizar.setInt(3, id);

        int linhasAfetadas = psAtualizar.executeUpdate();
        psAtualizar.close();

       JOptionPane.showMessageDialog(null, "Posto atualizado com sucesso");

    } catch (SQLException e) {
        throw new Exception(e);
    }
}

public void excluirPosto(int id) throws Exception {
    try {
        Connection cn = super.getCon();
        String excluirPosto = "DELETE FROM posto WHERE id = ?";
        PreparedStatement psExcluir = cn.prepareStatement(excluirPosto);
        psExcluir.setInt(1, id);

        int linhasAfetadas = psExcluir.executeUpdate();
        psExcluir.close();

  

    } catch (SQLException e) {
        throw new Exception(e);
    }
}
}
