package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import javax.swing.JButton;

public class Veiculo {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Veiculo window = new Veiculo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Veiculo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel Header = new JPanel();
		frame.getContentPane().add(Header, BorderLayout.NORTH);
		Header.setLayout(new BorderLayout(0, 0));
		
		JMenuBar menuBar_1 = new JMenuBar();
		Header.add(menuBar_1, BorderLayout.SOUTH);
		
		JMenu mnNewMenu_4 = new JMenu("Abastecimentos");
		menuBar_1.add(mnNewMenu_4);
		
		JMenu mnNewMenu_1_1 = new JMenu("Veiculos");
		menuBar_1.add(mnNewMenu_1_1);
		
		JMenu mnNewMenu_3_1 = new JMenu("Funcionarios");
		menuBar_1.add(mnNewMenu_3_1);
		
		JMenu mnNewMenu_2_1 = new JMenu("Postos");
		menuBar_1.add(mnNewMenu_2_1);
		
		JPanel panel_1 = new JPanel();
		Header.add(panel_1, BorderLayout.NORTH);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("New label");
		panel_1.add(lblNewLabel, BorderLayout.CENTER);
		
		JPanel Abastecimentos = new JPanel();
		frame.getContentPane().add(Abastecimentos, BorderLayout.CENTER);
		Abastecimentos.setLayout(new BorderLayout(0, 0));
		
		JPanel listaAbastecimentosl = new JPanel();
		Abastecimentos.add(listaAbastecimentosl, BorderLayout.EAST);
		listaAbastecimentosl.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Respons\u00E1vel", "Veiculo", "Posto", "TipoGasolina", "MediaKM", "Quantidade L", "Data"
			}
		));
		listaAbastecimentosl.add(table);
		
		JPanel listaInputs = new JPanel();
		Abastecimentos.add(listaInputs, BorderLayout.WEST);
		listaInputs.setLayout(new BorderLayout(0, 0));
		
		JPanel PainelInputs = new JPanel();
		listaInputs.add(PainelInputs, BorderLayout.NORTH);
		PainelInputs.setLayout(new GridLayout(0, 4, 0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		PainelInputs.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("New button");
		PainelInputs.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		PainelInputs.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("New button");
		PainelInputs.add(btnNewButton_1);
		
		JPanel panel_2 = new JPanel();
		listaInputs.add(panel_2, BorderLayout.SOUTH);
	}

}
