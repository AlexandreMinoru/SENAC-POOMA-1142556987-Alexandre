package View;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Control.BancoDados;
import Model.General.Abastecimento;
import Model.General.DonoVeiculo;
import Model.General.Posto;
import Model.General.Veiculo;

public class Interface extends JFrame{
	
	JPanel funcionario = new JPanel();

	BancoDados banco = new BancoDados();
	JPanel posto = new JPanel();
	JPanel abastecimento = new JPanel();
	JPanel veiculo = new JPanel();
	
	
	public Interface() throws MalformedURLException, IOException {
		setTitle("Primeira Java Swing");
		setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.red);
		banco.openDB();
		this.criarMenu();
		this.criarPainelAbastecimento();

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		this.revalidate();
		this.repaint();
		
		setVisible(true);
	}
	

	
	public void criarMenu() {

		JMenuBar barraMenu = new JMenuBar();
		JMenu abastecimento = new JMenu(), funcionario = new JMenu(), veiculo = new JMenu(), posto = new JMenu();
		JMenuItem a = new JMenuItem("IR"), b = new JMenuItem("IR"), c = new JMenuItem("IR"), d = new JMenuItem("IR");
		
		abastecimento.setText("Abastecimento");
		funcionario.setText("Funcionario");
		veiculo.setText("Veiculo");
		posto.setText("Posto");
		abastecimento.add(a);
		funcionario.add(b);
		veiculo.add(c);
		posto.add(d);
		barraMenu.add(abastecimento);
		barraMenu.add(funcionario);
		barraMenu.add(veiculo);
		barraMenu.add(posto);
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout());
		menu.add(barraMenu, BorderLayout.SOUTH);
		JPanel top = new JPanel();
		BufferedImage bufferedImage;
		top.setLayout(new BorderLayout());
		try {
			bufferedImage = ImageIO.read(new URL("https://img.freepik.com/psd-premium/carro-moderno-em-fundo-transparente-renderizacao-em-3d-ilustracao_494250-31500.jpg"));
			Image image = bufferedImage.getScaledInstance(70, 80, Image.SCALE_DEFAULT);
			JLabel img = new JLabel(new ImageIcon(image));
			top.add(img, BorderLayout.WEST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		top.setSize(1000, 200);
		top.add(new JLabel("teste"), BorderLayout.CENTER);
		menu.add(top, BorderLayout.NORTH);
		getContentPane().add(menu, BorderLayout.NORTH);
		a.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == a) {
				limparTela();
				criarPainelAbastecimento();
				}
				
			}
		});
		
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == b) {
				limparTela();
				criarPainelFuncionario();
				}
				
			}
		});
		
		c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == c) {
				limparTela();
				criarPainelCarro();
				}
				
			}
		});
		
		d.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == d) {
					limparTela();
					criarPainelPosto();
					}
				
			}
		});
	}
	
	
	public void criarPainelFuncionario() {
		funcionario.removeAll();
		funcionario.setBackground(Color.black);
		funcionario.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "Nome", "Idade","Telefone", "CPF", "Setor" };
	        JTable table = new JTable();

	        DefaultTableModel model = new DefaultTableModel(){

	            @Override
	            public boolean isCellEditable(int row, int column) {
	               //all cells false
	               return false;
	            }
	        };
	        model.setColumnIdentifiers(columnNames);
	        table.setModel(model);
	    
	        BancoDados banco = new BancoDados();

			criarListaFuncionarios(model, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		funcionario.add(painelInputFuncionarios());
		funcionario.add(painelLista);
		
		getContentPane().add(funcionario, BorderLayout.CENTER);

		
	}
	public void criarListaFuncionarios(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listarDonoVeiculo();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				DonoVeiculo novo = (DonoVeiculo) donosVeiculos.get(i);
				Vector vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getNome());
				vetor.add(Integer.toString(novo.getIdade()));
				vetor.add(novo.getTelefone());
				vetor.add(novo.getCpf());
				vetor.add(novo.getSetor());
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
  public JPanel painelInputFuncionarios() {
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[6];
	  listaLables[0] = "ID";
	  listaLables[1] = "Nome";
	  listaLables[2] = "Idade";
	  listaLables[3] = "Telefone";
	  listaLables[4] = "Cpf";
	  listaLables[5] = "Setor";
	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  
	  
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
  }
  
  public void criarPainelCarro() {
	  veiculo.removeAll();
		veiculo.setBackground(Color.black);
		veiculo.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "modelo", "Placa","Cor", "Dono"};
	        JTable table = new JTable();

	        DefaultTableModel model = new DefaultTableModel(){

	            @Override
	            public boolean isCellEditable(int row, int column) {
	               //all cells false
	               return false;
	            }
	        };
	        model.setColumnIdentifiers(columnNames);
	        table.setModel(model);
	    
	        BancoDados banco = new BancoDados();

			criarListaCarros(model, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		veiculo.add(painelInputCarros());
		veiculo.add(painelLista);
		
		getContentPane().add(veiculo, BorderLayout.CENTER);

		
	}
	public void criarListaCarros(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listaTodosVeiculos();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				Veiculo novo = (Veiculo) donosVeiculos.get(i);
				Vector<String> vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getModelo());
				vetor.add(novo.getPlaca());
				vetor.add(novo.getCor());
				vetor.add(novo.getDono().getNome());
				
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
public JPanel painelInputCarros() {
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[5];
	  listaLables[0] = "ID";
	  listaLables[1] = "Modelo";
	  listaLables[2] = "Placa";
	  listaLables[3] = "Cor";
	  listaLables[4] = "Dono";

	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  
	  
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
}


public void criarPainelPosto() {
	posto.removeAll();
		posto.setBackground(Color.black);
		posto.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "Marca", "Endereço"};
	        JTable table = new JTable();

	        DefaultTableModel model = new DefaultTableModel(){

	            @Override
	            public boolean isCellEditable(int row, int column) {
	               //all cells false
	               return false;
	            }
	        };
	        model.setColumnIdentifiers(columnNames);
	        table.setModel(model);
	    
	        BancoDados banco = new BancoDados();

			criarListaPosto(model, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		posto.add(painelInputPosto());
		posto.add(painelLista);
		
		getContentPane().add(posto, BorderLayout.CENTER);

		
	}
	public void criarListaPosto(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listarPostos();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				Posto novo = (Posto) donosVeiculos.get(i);
				Vector<String> vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getMarca());
				vetor.add(novo.getLocalizacao());

				
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
public JPanel painelInputPosto() {
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[3];
	  listaLables[0] = "ID";
	  listaLables[1] = "Marca";
	  listaLables[2] = "Endereço";
	 

	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  
	  
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
}

public void criarPainelAbastecimento() {
	abastecimento.removeAll();
	abastecimento.setBackground(Color.black);
	abastecimento.setLayout(new GridLayout(0,2));
	
	JPanel painelLista = new JPanel();
	painelLista.setLayout(null);
	JPanel painelBotoes = new JPanel();
	
 
        // Column Names
        String[] columnNames = { "ID", "Responsável", "Veiculo", "Posto", "TipoGasolina", "Quantidade", "Valor", "KmViajados","mediaKM", "Data"};
        JTable table = new JTable();

        DefaultTableModel model = new DefaultTableModel(){

            @Override
            public boolean isCellEditable(int row, int column) {
               //all cells false
               return false;
            }
        };
        model.setColumnIdentifiers(columnNames);
        table.setModel(model);
    
        BancoDados banco = new BancoDados();

		criarListaAbastecimento(model, banco);
			
		
			
        

	JScrollPane sp = new JScrollPane(table);
	sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
	painelLista.add(sp);

	abastecimento.add(painelInputAbastecimento());
	abastecimento.add(painelLista);
	
	getContentPane().add(abastecimento, BorderLayout.CENTER);

	
}
public void criarListaAbastecimento(DefaultTableModel model, BancoDados banco) {
	ArrayList donosVeiculos;
	try {
		donosVeiculos = banco.listarAbastecimentos();
		for (int i = 0; i < donosVeiculos.size(); i++) {
			Abastecimento novo = (Abastecimento) donosVeiculos.get(i);
			Vector<String> vetor = new Vector<>();
			vetor.add(Integer.toString(novo.getId()));
			vetor.add(novo.getResponsavel().getNome());
			vetor.add(novo.getVeiculo().getModelo());
			vetor.add(novo.getPosto().getMarca());
			vetor.add(novo.getTipoCombustivel());
			vetor.add(Double.toString(novo.getQuantidade()));
			vetor.add(Double.toString(novo.getPreco()));
			vetor.add(Double.toString(novo.getMediaKm()));
			vetor.add(novo.getData().toString());


			
			model.addRow(vetor);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

}

public JPanel painelInputAbastecimento() {
  JPanel painelInput = new JPanel();
  painelInput.setLayout(new GridLayout(4, 0));
  
  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
  String[] listaLables = new String[8];
  listaLables[0] = "ID";
  listaLables[1] = "Dono";
  listaLables[2] = "Veiculo";
  listaLables[3] = "Posto";
  listaLables[4] = "TipoGasolina";
  listaLables[5] = "Km viajados";
  listaLables[6] = "Valor";
  listaLables[7] = "Data";
  
 

  
  for (int i = 0; i < listaLables.length; i++) {
	 JPanel painel = new JPanel();
	 painel.setLayout(null);
	 JLabel lable = new JLabel(listaLables[i]);
	lable.setBounds(20, 50,60,50);
	painel.add(lable);
	JTextField input = new JTextField();
	input.setBounds(70, 65, 200,20);
	listaInputs.add(input);
	painel.add(input);
	painelInput.add(painel);
}
  JPanel botoes = new JPanel();
  botoes.setLayout(new FlowLayout());
  
  JButton botaoAdicionar = new JButton("Adicionar");
  botaoAdicionar.setBackground(Color.green);
  botaoAdicionar.setForeground(Color.black);
  JButton botaoRemover = new JButton("Remover");
  botaoRemover.setBackground(Color.red);
  botaoRemover.setForeground(Color.black);
  JButton botaoEditar = new JButton("Editar");
  botaoEditar.setBackground(Color.blue);
  botaoEditar.setForeground(Color.white);
  
  botoes.add(botaoAdicionar);
  botoes.add(botaoEditar);
  botoes.add(botaoRemover);
  
  
  
  JPanel completo = new JPanel();
  completo.setLayout(new BorderLayout());
  completo.add(painelInput, BorderLayout.CENTER);
  completo.add(botoes, BorderLayout.SOUTH);
  return completo;
}

public void limparTela() {
	try {
		this.remove(abastecimento);
		
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(posto);
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(funcionario);
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(veiculo);
	}catch (Exception e) {
		// TODO: handle exception
	}
	getContentPane().repaint();
	getContentPane().revalidate();
}
}
