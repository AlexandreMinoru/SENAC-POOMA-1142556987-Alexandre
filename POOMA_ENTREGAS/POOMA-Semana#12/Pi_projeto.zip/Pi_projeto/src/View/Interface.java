package View;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Interface extends JFrame{
	
	

	
	public Interface() throws MalformedURLException, IOException {
		setTitle("Primeira Java Swing");
		setSize(1000,1000);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.red);
		
		this.criarMenu();
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		this.revalidate();
		this.repaint();
		
		setVisible(true);
	}
	

	
	public void criarMenu() {
		JMenuBar barraMenu = new JMenuBar();
		JMenu abastecimento = new JMenu(), funcionario = new JMenu(), veiculo = new JMenu(), posto = new JMenu();
		
		abastecimento.setText("Abastecimento");
		funcionario.setText("Funcionario");
		veiculo.setText("Veiculo");
		posto.setText("Posto");
		barraMenu.add(abastecimento);
		barraMenu.add(funcionario);
		barraMenu.add(veiculo);
		barraMenu.add(posto);
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout());
		menu.add(barraMenu, BorderLayout.SOUTH);
		JPanel top = new JPanel();
		BufferedImage bufferedImage;
		top.setLayout(new BorderLayout());
		try {
			bufferedImage = ImageIO.read(new URL("https://img.freepik.com/psd-premium/carro-moderno-em-fundo-transparente-renderizacao-em-3d-ilustracao_494250-31500.jpg"));
			Image image = bufferedImage.getScaledInstance(70, 80, Image.SCALE_DEFAULT);
			JLabel img = new JLabel(new ImageIcon(image));
			top.add(img, BorderLayout.WEST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		top.setSize(1000, 200);
		top.add(new JLabel("teste"), BorderLayout.CENTER);
		menu.add(top, BorderLayout.NORTH);
		getContentPane().add(menu, BorderLayout.NORTH);
		
	}
}
