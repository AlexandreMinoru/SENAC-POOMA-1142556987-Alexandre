package View;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Control.BancoDados;
import Model.General.DonoVeiculo;

public class Interface extends JFrame{
	
	JPanel funcionario = new JPanel();

	
	public Interface() throws MalformedURLException, IOException {
		setTitle("Primeira Java Swing");
		setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.red);
		
		this.criarMenu();
		this.criarPainelFucnionario();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		this.revalidate();
		this.repaint();
		
		setVisible(true);
	}
	

	
	public void criarMenu() {

		JMenuBar barraMenu = new JMenuBar();
		JMenu abastecimento = new JMenu(), funcionario = new JMenu(), veiculo = new JMenu(), posto = new JMenu();
		
		abastecimento.setText("Abastecimento");
		funcionario.setText("Funcionario");
		veiculo.setText("Veiculo");
		posto.setText("Posto");
		barraMenu.add(abastecimento);
		barraMenu.add(funcionario);
		barraMenu.add(veiculo);
		barraMenu.add(posto);
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout());
		menu.add(barraMenu, BorderLayout.SOUTH);
		JPanel top = new JPanel();
		BufferedImage bufferedImage;
		top.setLayout(new BorderLayout());
		try {
			bufferedImage = ImageIO.read(new URL("https://img.freepik.com/psd-premium/carro-moderno-em-fundo-transparente-renderizacao-em-3d-ilustracao_494250-31500.jpg"));
			Image image = bufferedImage.getScaledInstance(70, 80, Image.SCALE_DEFAULT);
			JLabel img = new JLabel(new ImageIcon(image));
			top.add(img, BorderLayout.WEST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		top.setSize(1000, 200);
		top.add(new JLabel("teste"), BorderLayout.CENTER);
		menu.add(top, BorderLayout.NORTH);
		getContentPane().add(menu, BorderLayout.NORTH);
		
	}
	
	
	public void criarPainelFucnionario() {
		funcionario.setBackground(Color.black);
		funcionario.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
	painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		String[][] data = {
	            
	        };
	 
	        // Column Names
	        String[] columnNames = { "ID", "Nome", "Idade","Telefone","Setor" };
	        JTable table = new JTable();

	        DefaultTableModel model = new DefaultTableModel(){

	            @Override
	            public boolean isCellEditable(int row, int column) {
	               //all cells false
	               return false;
	            }
	        };
	        model.setColumnIdentifiers(columnNames);
	        table.setModel(model);
	    
	        BancoDados banco = new BancoDados();
	        try {
				ArrayList donosVeiculos = banco.listarDonoVeiculo();
				for (int i = 0; i < donosVeiculos.size(); i++) {
					DonoVeiculo novo = (DonoVeiculo) donosVeiculos.get(i);
					Vector vetor = new Vector<>();
					vetor.add(Integer.toString(novo.getId()));
					vetor.add(novo.getNome());
					vetor.add(Integer.toString(novo.getIdade()));
					vetor.add(novo.getTelefone());
					vetor.add(novo.getSetor());
					model.addRow(vetor);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 800, 10000);
		painelLista.add(sp);
		table.add(new JLabel("teste"));
		table.setBackground(Color.white);
		funcionario.add(painelBotoes);
		funcionario.add(painelLista);
		
		getContentPane().add(funcionario, BorderLayout.CENTER);

		
	}
	
	
}
