package View;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DateFormatter;

import org.jdatepicker.DateModel;
import org.jdatepicker.JDatePicker;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import Control.BancoDados;
import Model.General.Abastecimento;
import Model.General.DateLabelFormatter;
import Model.General.DonoVeiculo;
import Model.General.Posto;
import Model.General.Veiculo;

public class Interface extends JFrame{
	
	JPanel funcionario = new JPanel();
	JDatePickerImpl datePicker = null;
	BancoDados banco = new BancoDados();
	JPanel posto = new JPanel();
	JPanel abastecimento = new JPanel();
	JPanel veiculo = new JPanel();
	DefaultTableModel modelPosto = new DefaultTableModel(){

        @Override
        public boolean isCellEditable(int row, int column) {
           //all cells false
           return false;
        }
    };
    DefaultTableModel modelFuncionario = new DefaultTableModel(){

        @Override
        public boolean isCellEditable(int row, int column) {
           //all cells false
           return false;
        }
    };
    DefaultTableModel modelVeiculo = new DefaultTableModel(){

        @Override
        public boolean isCellEditable(int row, int column) {
           //all cells false
           return false;
        }
    };
    DefaultTableModel model = new DefaultTableModel(){

        @Override
        public boolean isCellEditable(int row, int column) {
           //all cells false
           return false;
        }
    };
	  JRadioButton comum = new JRadioButton("Comum");
	  JRadioButton aditiva = new JRadioButton("Aditivada");
	  JRadioButton contabil = new JRadioButton("Contábil");
	  JRadioButton transporte = new JRadioButton("transporte");
	  JRadioButton financeiro = new JRadioButton("financeiro");
	  JRadioButton ti = new JRadioButton("ti");
	  
	  private String datePattern = "yyyy-MM-dd";
	    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);
	public Interface() throws MalformedURLException, IOException {
		setTitle("Primeira Java Swing");
		setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.red);
		banco.openDB();
		this.criarMenu();
		this.criarPainelAbastecimento();

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		this.revalidate();
		this.repaint();
		
		setVisible(true);
	}
	

	
	public void criarMenu() {

		JMenuBar barraMenu = new JMenuBar();
		JMenu abastecimento = new JMenu(), funcionario = new JMenu(), veiculo = new JMenu(), posto = new JMenu();
		JMenuItem a = new JMenuItem("IR"), b = new JMenuItem("IR"), c = new JMenuItem("IR"), d = new JMenuItem("IR");
		
		abastecimento.setText("Abastecimento");
		funcionario.setText("Funcionario");
		veiculo.setText("Veiculo");
		posto.setText("Posto");
		abastecimento.add(a);
		funcionario.add(b);
		veiculo.add(c);
		posto.add(d);
		barraMenu.add(abastecimento);
		barraMenu.add(funcionario);
		barraMenu.add(veiculo);
		barraMenu.add(posto);
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout());
		menu.add(barraMenu, BorderLayout.SOUTH);
		JPanel top = new JPanel();
		BufferedImage bufferedImage;
		top.setLayout(new BorderLayout());
		try {
			bufferedImage = ImageIO.read(new URL("https://img.freepik.com/vetores-premium/design-de-modelo-de-logotipo-de-posto-de-gasolina_316488-426.jpg"));
			Image image = bufferedImage.getScaledInstance(200, 100, Image.SCALE_DEFAULT);
			JLabel img = new JLabel(new ImageIcon(image));
			top.add(img, BorderLayout.WEST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		top.setSize(1000, 200);
		menu.add(top, BorderLayout.NORTH);
		getContentPane().add(menu, BorderLayout.NORTH);
		a.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == a) {
				limparTela();
				criarPainelAbastecimento();
				}
				
			}
		});
		
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == b) {
				limparTela();
				criarPainelFuncionario();
				}
				
			}
		});
		
		c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == c) {
				limparTela();
				criarPainelCarro();
				}
				
			}
		});
		
		d.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == d) {
					limparTela();
					criarPainelPosto();
					}
				
			}
		});
	}
	
	
	public void criarPainelFuncionario() {
		 try {
			  removerRow(modelFuncionario);
		  }catch (Exception e) {
			// TODO: handle exception
		}
		funcionario.removeAll();
		funcionario.setBackground(Color.black);
		funcionario.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "Nome", "Idade","Telefone", "CPF", "Setor" };
	        JTable table = new JTable();

	       
	        modelFuncionario.setColumnIdentifiers(columnNames);
	        table.setModel(modelFuncionario);
	    
	        BancoDados banco = new BancoDados();

			criarListaFuncionarios(modelFuncionario, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		funcionario.add(painelInputFuncionarios(table));
		funcionario.add(painelLista);
		
		getContentPane().add(funcionario, BorderLayout.CENTER);

		
	}
	public void criarListaFuncionarios(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listarDonoVeiculo();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				DonoVeiculo novo = (DonoVeiculo) donosVeiculos.get(i);
				Vector vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getNome());
				vetor.add(Integer.toString(novo.getIdade()));
				vetor.add(novo.getTelefone());
				vetor.add(novo.getCpf());
				vetor.add(novo.getSetor());
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
  public JPanel painelInputFuncionarios(JTable table) {
	 
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[6];
	  listaLables[0] = "ID";
	  listaLables[1] = "Nome";
	  listaLables[2] = "Idade";
	  listaLables[3] = "Telefone";
	  listaLables[4] = "Cpf";
	  listaLables[5] = "Setor";
	  
	  for (int i = 0; i < listaLables.length; i++) {
		  if( i == 5) {
			  JPanel painel = new JPanel();
			  painel.setLayout(null);
			  ButtonGroup grupoTipoGasolina = new ButtonGroup();
			  grupoTipoGasolina.add(contabil);
			  grupoTipoGasolina.add(transporte);
			  grupoTipoGasolina.add(financeiro);
			  grupoTipoGasolina.add(ti);
			  JLabel lable = new JLabel("Setor");
			  lable.setBounds(150, 20, 80, 50);
			  contabil.setBounds(0,50,80,50);
			  transporte.setBounds(100,50,100,50);
			  financeiro.setBounds(200,50,100,50);
			  ti.setBounds(300,50,80,50);
			  painel.add(lable);
			  painel.add(contabil);
			  painel.add(transporte);
			  painel.add(financeiro);
			  painel.add(ti);
			  painelInput.add(painel);
		  }else {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
		  }
	}
	  
	  
	  table.addMouseListener(new java.awt.event.MouseAdapter() {
	       @Override
	       public void mouseClicked(java.awt.event.MouseEvent evt) {

	           int row = table.getSelectedRow();
	           int col = table.getSelectedColumn();
	           
	           
	           
	           listaInputs.get(0).setText((String) (table.getValueAt(row, 0)));
	           listaInputs.get(1).setText((String) (table.getValueAt(row, 1)));
	           listaInputs.get(2).setText((String) (table.getValueAt(row, 2)));
	           listaInputs.get(3).setText((String) (table.getValueAt(row, 3)));
	           listaInputs.get(4).setText((String) (table.getValueAt(row, 4)));
	           String texto = (String) (table.getValueAt(row, 5));
	           if(texto.equals("Contabilidade")) {
	        	   contabil.setSelected(true);
	           }else if(texto.equals("Transporte")) {
	        	   transporte.setSelected(true);
	           }else if(texto.equals("Financeiro")) {
	        	   financeiro.setSelected(true);
	           } if(texto.equals("TI")) {
	        	   ti.setSelected(true);
	           }
	       }});
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  
	  
	  botaoAdicionar.addActionListener(new ActionListener() {
			
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == botaoAdicionar) {
				if(listaInputs.get(1).getText().equals("") || listaInputs.get(2).getText().equals("") || listaInputs.get(3).getText().equals("") ||  listaInputs.get(4).getText().equals("")){
					JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos");
					return;
				}
					if(contabil.isSelected()) {
						try {
							banco.adicionarDonoVeiculo(listaInputs.get(1).getText(), Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(), 1);
						}catch (Exception exception) {
							JOptionPane.showMessageDialog(null, "Por favor, na área IDADE, deve ser informado um número");
							return;
						}
						
					} else if(transporte.isSelected()) {
						try {
							banco.adicionarDonoVeiculo(listaInputs.get(1).getText(), Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(), 2);
						}catch (Exception exception) {
							JOptionPane.showMessageDialog(null, "Por favor, na área IDADE, deve ser informado um número");
							return;
						}
						
					}else if(financeiro.isSelected()) {
						try {
							banco.adicionarDonoVeiculo(listaInputs.get(1).getText(), Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(), 3);
						}catch (Exception exception) {
							JOptionPane.showMessageDialog(null, "Por favor, na área IDADE, deve ser informado um número");
							return;
						}
						
					}else if(ti.isSelected()) {
						try {
							banco.adicionarDonoVeiculo(listaInputs.get(1).getText(), Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(), 4);
						}catch (Exception exception) {
							JOptionPane.showMessageDialog(null, "Por favor, na área IDADE, deve ser informado um número");
							return;
						}
						
					}
					removerRow(modelFuncionario);
					criarListaFuncionarios(modelFuncionario, banco);

			}
			
		}
	});
	  
	  botaoEditar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == botaoEditar) {
					try {

						
						
						
						
						if(contabil.isSelected()) {
							banco.editarDonoVeiculo( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(),1);
						}else if(transporte.isSelected()) {
							banco.editarDonoVeiculo( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(),2);
						}else if(financeiro.isSelected()) {
							banco.editarDonoVeiculo( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(),3);
						}else if(ti.isSelected()) {
							banco.editarDonoVeiculo( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),Integer.parseInt(listaInputs.get(2).getText()), listaInputs.get(3).getText(), listaInputs.get(4).getText(),4);
						}
						
						
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "Na área idade deve ser informado um número");
						e1.printStackTrace();
					}
				}
				 removerRow(modelFuncionario);
				 criarListaFuncionarios(modelFuncionario, banco);
			}
				
			
		});
		  
		  
		  botaoRemover.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int reply = 0;
				if(contabil.isSelected()) {
					
					reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o Funcionário:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Contábil" , "?", JOptionPane.YES_NO_OPTION);
				}else if(transporte.isSelected()) {
					reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o Funcionário:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Transporte" , "?", JOptionPane.YES_NO_OPTION);
				}else if(financeiro.isSelected()) {
					reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o Funcionário:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Financeiro" , "?", JOptionPane.YES_NO_OPTION);
				}else if(ti.isSelected()) {
					reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o Funcionário:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Ti" , "?", JOptionPane.YES_NO_OPTION);
				}
				
				if(reply == JOptionPane.YES_OPTION) {
					if(e.getSource() == botaoRemover) {
						try {
							
							
							banco.removerDonoVeiculo(Integer.parseInt(listaInputs.get(0).getText()));
							JOptionPane.showMessageDialog(null, "Removido com sucesso");
						}  catch (Exception e1) {
							
						}
					}
					
				}else {
					return;
				}
				
				
				 removerRow(modelFuncionario);
				 criarListaFuncionarios(modelFuncionario, banco);
				
			}
		});
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
  }
  
  public void criarPainelCarro() {
	  try {
			removerRow(modelVeiculo);
		}catch (Exception e) {
			// TODO: handle exception
		}
	  veiculo.removeAll();
		veiculo.setBackground(Color.black);
		veiculo.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "modelo", "Placa","Cor", "Dono"};
	        JTable table = new JTable();

	     
	        modelVeiculo.setColumnIdentifiers(columnNames);
	        table.setModel(modelVeiculo);
	    
	        BancoDados banco = new BancoDados();

			criarListaCarros(modelVeiculo, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		veiculo.add(painelInputCarros(table));
		veiculo.add(painelLista);
		
		getContentPane().add(veiculo, BorderLayout.CENTER);

		
	}
	public void criarListaCarros(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listaTodosVeiculos();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				Veiculo novo = (Veiculo) donosVeiculos.get(i);
				Vector<String> vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getModelo());
				vetor.add(novo.getPlaca());
				vetor.add(novo.getCor());
				vetor.add(novo.getDono().getNome());
				
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
public JPanel painelInputCarros(JTable table) {
	
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[5];
	  listaLables[0] = "ID";
	  listaLables[1] = "Modelo";
	  listaLables[2] = "Placa";
	  listaLables[3] = "Cor";
	  listaLables[4] = "Dono";

	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  
	  table.addMouseListener(new java.awt.event.MouseAdapter() {
	       @Override
	       public void mouseClicked(java.awt.event.MouseEvent evt) {

	           int row = table.getSelectedRow();
	           int col = table.getSelectedColumn();
	           
	           
	           
	           listaInputs.get(0).setText((String) (table.getValueAt(row, 0)));
	           listaInputs.get(1).setText((String) (table.getValueAt(row, 1)));
	           listaInputs.get(2).setText((String) (table.getValueAt(row, 2)));
	           listaInputs.get(3).setText((String) (table.getValueAt(row, 3)));
	           listaInputs.get(4).setText((String) (table.getValueAt(row, 4)));
	        
	          
	       }});
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  botaoAdicionar.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == botaoAdicionar) {
				try {
					banco.adicionarVeiculo(listaInputs.get(1).getText(), listaInputs.get(2).getText(), listaInputs.get(4).getText(), listaInputs.get(3).getText());
					removerRow(modelVeiculo);
					criarListaCarros(modelVeiculo, banco);
				}catch (Exception exception) {
					JOptionPane.showMessageDialog(null, "Funcionário não encontrado");
				}
				
			}
			
		}
	});
	  
	  botaoEditar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == botaoEditar) {
					try {

						
						
						
						banco.editarVeiculo(Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(2).getText() , listaInputs.get(3).getText(), listaInputs.get(1).getText(), listaInputs.get(4).getText());
						
						
						
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
						e1.printStackTrace();
					}
				}
				 removerRow(modelVeiculo);
				 criarListaCarros(modelVeiculo, banco);
			}
				
			
		});
		  
		  
		  botaoRemover.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == botaoRemover) {
				int reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o posto:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Contábil" , "?", JOptionPane.YES_NO_OPTION);
				
				
				if(reply == JOptionPane.YES_OPTION) {
					if(e.getSource() == botaoRemover) {
						try {
							
							
							banco.removerVeiculo(Integer.parseInt(listaInputs.get(0).getText()));
							JOptionPane.showMessageDialog(null, "Removido com sucesso");
						}  catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
				removerRow(modelVeiculo);
				 criarListaCarros(modelVeiculo, banco);
				}
				
				
				 
				
			}
		});
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
}


public void criarPainelPosto() {
	 try {
		  removerRow(modelPosto);
	  }catch (Exception e) {
		// TODO: handle exception
	}
	posto.removeAll();
		posto.setBackground(Color.black);
		posto.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "Marca", "Endereço"};
	        JTable table = new JTable();

	       
	        modelPosto.setColumnIdentifiers(columnNames);
	        table.setModel(modelPosto);
	    
	        BancoDados banco = new BancoDados();

			criarListaPosto(modelPosto, banco);
				
			
			
			table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
			
			

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		posto.add(painelInputPosto(table));
		posto.add(painelLista);
		
		getContentPane().add(posto, BorderLayout.CENTER);

		
	}
	public void criarListaPosto(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listarPostos();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				Posto novo = (Posto) donosVeiculos.get(i);
				Vector<String> vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getMarca());
				vetor.add(novo.getLocalizacao());

				
						
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
public JPanel painelInputPosto(JTable table) {
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[3];
	  listaLables[0] = "ID";
	  listaLables[1] = "Marca";
	  listaLables[2] = "Endereço";
	 

	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(90, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  
	  
	  table.addMouseListener(new java.awt.event.MouseAdapter() {
	       @Override
	       public void mouseClicked(java.awt.event.MouseEvent evt) {

	           int row = table.getSelectedRow();
	           int col = table.getSelectedColumn();
	           
	           
	           listaInputs.get(0).setText((String) (table.getValueAt(row, 0)));
	           listaInputs.get(1).setText((String) (table.getValueAt(row, 1)));
	           listaInputs.get(2).setText((String) (table.getValueAt(row, 2)));
	       }});
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  botaoAdicionar.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == botaoAdicionar) {
				if(listaInputs.get(1).getText().equals("") || listaInputs.get(2).getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos");
					return;
				}
					banco.adicionarPosto(listaInputs.get(2).getText(), listaInputs.get(1).getText());
					removerRow(modelPosto);
					criarListaPosto(modelPosto, banco);

			}
			
		}
	});
	  
	  botaoEditar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == botaoEditar) {
					try {

						
						
						
						banco.editarPosto(Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(2).getText() , listaInputs.get(1).getText());
						
						
						
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
						e1.printStackTrace();
					}
				}
				 removerRow(modelPosto);
				 criarListaPosto(modelPosto, banco);
			}
				
			
		});
		  
		  
		  botaoRemover.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o posto:\n ID: " + listaInputs.get(0).getText() + "\nNome " + listaInputs.get(2).getText() + "\nSetor: Contábil" , "?", JOptionPane.YES_NO_OPTION);
				
				
				if(reply == JOptionPane.YES_OPTION) {
					if(e.getSource() == botaoRemover) {
						try {
							
							
							banco.excluirPosto(Integer.parseInt(listaInputs.get(0).getText()));
							JOptionPane.showMessageDialog(null, "Removido com sucesso");
						}  catch (Exception e1) {
							
						}
					}
					
				}else {
					return;
				}
				
				
				removerRow(modelPosto);
				 criarListaPosto(modelPosto, banco);
				
			}
		});
	  
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
}

public void criarPainelAbastecimento() {
	try {
		  removerRow(model);
	  }catch (Exception e) {
		// TODO: handle exception
	}
	abastecimento.removeAll();
	abastecimento.setBackground(Color.black);
	abastecimento.setLayout(new GridLayout(0,2));
	
	JPanel painelLista = new JPanel();
	painelLista.setLayout(null);
	JPanel painelBotoes = new JPanel();
	
 
        // Column Names
        String[] columnNames = { "ID", "Responsável", "Veiculo", "Posto", "TipoGasolina", "Quantidade", "Valor", "KmViajados","mediaKM", "Data"};
        JTable table = new JTable();

        
        model.setColumnIdentifiers(columnNames);
        table.setModel(model);
    
        BancoDados banco = new BancoDados();

		criarListaAbastecimento(model, banco);
			
		
			
        

	JScrollPane sp = new JScrollPane(table);
	sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
	painelLista.add(sp);

	abastecimento.add(painelInputAbastecimento(table));
	abastecimento.add(painelLista);
	
	getContentPane().add(abastecimento, BorderLayout.CENTER);

	
}
public void criarListaAbastecimento(DefaultTableModel model, BancoDados banco) {
	ArrayList donosVeiculos;
	try {
		donosVeiculos = banco.listarAbastecimentos();
		for (int i = 0; i < donosVeiculos.size(); i++) {
			Abastecimento novo = (Abastecimento) donosVeiculos.get(i);
			Vector<String> vetor = new Vector<>();
			vetor.add(Integer.toString(novo.getId()));
			vetor.add(novo.getResponsavel().getNome());
			vetor.add(novo.getVeiculo().getModelo());
			vetor.add(novo.getPosto().getMarca());
			vetor.add(novo.getTipoCombustivel());
			vetor.add(Double.toString(novo.getQuantidade()));
			vetor.add(Double.toString(novo.getPreco()));
			vetor.add(Double.toString(novo.getKmViajados()));
			vetor.add(Double.toString(novo.getMediaKm()));
			vetor.add(novo.getData());


			
			model.addRow(vetor);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

}

public JPanel painelInputAbastecimento(JTable table) {
	
  JPanel painelInput = new JPanel();
  UtilDateModel model = new UtilDateModel();
  JDatePanelImpl datePanel = null;
  painelInput.setLayout(new GridLayout(4, 0));
  
  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
  String[] listaLables = new String[8];
  listaLables[0] = "ID";
  listaLables[1] = "Dono";
  listaLables[2] = "Veiculo";
  listaLables[3] = "Posto";
  listaLables[4] = "TipoGasolina";
  listaLables[5] = "Km viajados";
  listaLables[6] = "Valor";
  listaLables[7] = "Data";
  
 

  
  for (int i = 0; i < listaLables.length; i++) {
	  
	  if(i ==4) {

		  ButtonGroup grupoTipoGasolina = new ButtonGroup();
		  grupoTipoGasolina.add(comum);
		  grupoTipoGasolina.add(aditiva);
		  comum.setBounds(20, 50, 80, 50);
		  aditiva.setBounds(100, 50, 80, 50);
		  JPanel painel = new JPanel();
		 
		painel.setLayout(null);
		painel.add(comum);
		painel.add(aditiva);
		painelInput.add(painel);
	  }else if(i == 7){
		  
		  Properties p = new Properties();
		  p.put("today", "Today");
		  p.put("month", "Month");
		  p.put("year", "Year");
		  datePanel = new JDatePanelImpl(model, p);
	         datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
	        JPanel painel = new JPanel();
	        JLabel label = new JLabel("Data");
	        label.setBounds(10, 20, 40, 40);
	        datePicker.setBounds(60, 20, 200, 40);
	        painel.setLayout(null);
	        painel.add(label);
	        painel.add(datePicker);
	        painelInput.add(painel);
		
	  }else {
	 JPanel painel = new JPanel();
	 painel.setLayout(null);
	 JLabel lable = new JLabel(listaLables[i]);
	lable.setBounds(20, 50,80,50);
	painel.add(lable);
	JTextField input = new JTextField();
	input.setBounds(90, 65, 200,20);
	listaInputs.add(input);
	painel.add(input);
	painelInput.add(painel);
	  }
	  }
  table.addMouseListener(new java.awt.event.MouseAdapter() {
      @Override
      public void mouseClicked(java.awt.event.MouseEvent evt) {
    	  
          int row = table.getSelectedRow();
          int col = table.getSelectedColumn();
          
          
          
          listaInputs.get(0).setText((String) (table.getValueAt(row, 0)));
          listaInputs.get(1).setText((String) (table.getValueAt(row, 1)));
          listaInputs.get(2).setText((String) (table.getValueAt(row, 2)));
          listaInputs.get(3).setText((String) (table.getValueAt(row, 3)));
          listaInputs.get(4).setText((String) (table.getValueAt(row, 5)));
          listaInputs.get(5).setText((String) (table.getValueAt(row, 6)));
          String data = (String) (table.getValueAt(row, 9));
      
          String texto = (String) (table.getValueAt(row, 4));
          
          if(texto.equals("Comum")) {
        	  comum.setSelected(true);
          }else if(texto.equals("Aditivada")){
        	  aditiva.setSelected(true);
          }
          
          String[] linha = data.split("-",3);
          int ano = Integer.parseInt(linha[0]);
          int dia = Integer.parseInt(linha[2]);
          int mes  = Integer.parseInt(linha[1]);
          mes -= 1;
         
       

      datePicker.getModel().setDate(ano, mes, dia);
      }});
  JPanel botoes = new JPanel();
  botoes.setLayout(new FlowLayout());
  
  JButton botaoAdicionar = new JButton("Adicionar");
  botaoAdicionar.setBackground(Color.green);
  botaoAdicionar.setForeground(Color.black);
  JButton botaoRemover = new JButton("Remover");
  botaoRemover.setBackground(Color.red);
  botaoRemover.setForeground(Color.black);
  JButton botaoEditar = new JButton("Editar");
  botaoEditar.setBackground(Color.blue);
  botaoEditar.setForeground(Color.white);
  
  botoes.add(botaoAdicionar);
  botoes.add(botaoEditar);
  botoes.add(botaoRemover);
  
  botaoAdicionar.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == botaoAdicionar) {
			try {

				SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd");
				
				
				
				if(comum.isSelected()) {
					banco.adicionarAbastecimento(listaInputs.get(1).getText(),listaInputs.get(2).getText(), listaInputs.get(3).getText(),1, Double.parseDouble(listaInputs.get(4).getText()),Double.parseDouble(listaInputs.get(5).getText()) ,format.format(datePicker.getModel().getValue() ));
				}else if(aditiva.isSelected()) {
					banco.adicionarAbastecimento(listaInputs.get(1).getText(),listaInputs.get(2).getText(), listaInputs.get(3).getText(),2, Double.parseDouble(listaInputs.get(4).getText()),Double.parseDouble(listaInputs.get(5).getText()) ,format.format(datePicker.getModel().getValue() ));
				}
				
				
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, "Na área Valor e KM viajados devem ser informados números");
			}
		}
		 removerRow(Interface.this.model);
		 criarListaAbastecimento(Interface.this.model, banco);
	}
});
  
  botaoEditar.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == botaoEditar) {
			try {

				SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd");
				
				
				
				if(comum.isSelected()) {
					banco.editarAbastecimento( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),listaInputs.get(2).getText(), listaInputs.get(3).getText(),1, Double.parseDouble(listaInputs.get(4).getText()),Double.parseDouble(listaInputs.get(5).getText()) ,format.format(datePicker.getModel().getValue()));
				}else if(aditiva.isSelected()) {
					banco.editarAbastecimento( Integer.parseInt(listaInputs.get(0).getText()),listaInputs.get(1).getText(),listaInputs.get(2).getText(), listaInputs.get(3).getText(),2, Double.parseDouble(listaInputs.get(4).getText()),Double.parseDouble(listaInputs.get(5).getText()) ,format.format(datePicker.getModel().getValue()));
				}
				
				
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, "Na área Valor e KM viajados devem ser informados números");
				e1.printStackTrace();
			}
		}
		 removerRow(Interface.this.model);
		 criarListaAbastecimento(Interface.this.model, banco);
	}
		
	
});
  
  
  botaoRemover.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		SimpleDateFormat format =  new SimpleDateFormat("yyyy-MM-dd");
		int reply = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover o abastecimeto:\n ID: " + listaInputs.get(0).getText() + "\nVeiculo " + listaInputs.get(2).getText() + "\nData: " + format.format(datePicker.getModel().getValue()), "?", JOptionPane.YES_NO_OPTION);
		if(reply == JOptionPane.YES_OPTION) {
			if(e.getSource() == botaoRemover) {
				try {
					banco.excluirAbastecimento(Integer.parseInt(listaInputs.get(0).getText()));
					JOptionPane.showMessageDialog(null, "Removido com sucesso");
				}  catch (Exception e1) {
					
				}
			}
			
		}else {
			return;
		}
		
		
		 removerRow(Interface.this.model);
		 criarListaAbastecimento(Interface.this.model, banco);
		
	}
});
  JPanel completo = new JPanel();
  completo.setLayout(new BorderLayout());
  completo.add(painelInput, BorderLayout.CENTER);
  completo.add(botoes, BorderLayout.SOUTH);
  return completo;
}

public void limparTela() {
	try {
		this.remove(abastecimento);
		
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(posto);
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(funcionario);
	}catch (Exception e) {
		// TODO: handle exception
	}
	try {
		this.remove(veiculo);
	}catch (Exception e) {
		// TODO: handle exception
	}
	getContentPane().repaint();
	getContentPane().revalidate();
}

private void removerRow(DefaultTableModel model) {
	for (int i = 0; i < model.getRowCount(); i++) {
		model.setRowCount(0);
	}
}

private String formatDate(LocalDate date) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    return date.format(formatter);
}
}


