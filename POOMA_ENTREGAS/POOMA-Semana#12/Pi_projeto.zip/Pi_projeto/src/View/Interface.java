package View;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Control.BancoDados;
import Model.General.DonoVeiculo;

public class Interface extends JFrame{
	
	JPanel funcionario = new JPanel();

	
	public Interface() throws MalformedURLException, IOException {
		setTitle("Primeira Java Swing");
		setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.red);
		
		this.criarMenu();
		this.criarPainelFuncionario();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		this.revalidate();
		this.repaint();
		
		setVisible(true);
	}
	

	
	public void criarMenu() {

		JMenuBar barraMenu = new JMenuBar();
		JMenu abastecimento = new JMenu(), funcionario = new JMenu(), veiculo = new JMenu(), posto = new JMenu();
		
		abastecimento.setText("Abastecimento");
		funcionario.setText("Funcionario");
		veiculo.setText("Veiculo");
		posto.setText("Posto");
		barraMenu.add(abastecimento);
		barraMenu.add(funcionario);
		barraMenu.add(veiculo);
		barraMenu.add(posto);
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout());
		menu.add(barraMenu, BorderLayout.SOUTH);
		JPanel top = new JPanel();
		BufferedImage bufferedImage;
		top.setLayout(new BorderLayout());
		try {
			bufferedImage = ImageIO.read(new URL("https://img.freepik.com/psd-premium/carro-moderno-em-fundo-transparente-renderizacao-em-3d-ilustracao_494250-31500.jpg"));
			Image image = bufferedImage.getScaledInstance(70, 80, Image.SCALE_DEFAULT);
			JLabel img = new JLabel(new ImageIcon(image));
			top.add(img, BorderLayout.WEST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		top.setSize(1000, 200);
		top.add(new JLabel("teste"), BorderLayout.CENTER);
		menu.add(top, BorderLayout.NORTH);
		getContentPane().add(menu, BorderLayout.NORTH);
		
	}
	
	
	public void criarPainelFuncionario() {
		funcionario.setBackground(Color.black);
		funcionario.setLayout(new GridLayout(0,2));
		
		JPanel painelLista = new JPanel();
		painelLista.setLayout(null);
		JPanel painelBotoes = new JPanel();
		
	 
	        // Column Names
	        String[] columnNames = { "ID", "Nome", "Idade","Telefone", "CPF", "Setor" };
	        JTable table = new JTable();

	        DefaultTableModel model = new DefaultTableModel(){

	            @Override
	            public boolean isCellEditable(int row, int column) {
	               //all cells false
	               return false;
	            }
	        };
	        model.setColumnIdentifiers(columnNames);
	        table.setModel(model);
	    
	        BancoDados banco = new BancoDados();

			criarListaFuncionarios(model, banco);
				
			
				
	        

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(SwingConstants.CENTER, SwingConstants.CENTER, 700, 10000);
		painelLista.add(sp);

		funcionario.add(painelInputFuncionarios());
		funcionario.add(painelLista);
		
		getContentPane().add(funcionario, BorderLayout.CENTER);

		
	}
	public void criarListaFuncionarios(DefaultTableModel model, BancoDados banco) {
		ArrayList donosVeiculos;
		try {
			donosVeiculos = banco.listarDonoVeiculo();
			for (int i = 0; i < donosVeiculos.size(); i++) {
				DonoVeiculo novo = (DonoVeiculo) donosVeiculos.get(i);
				Vector vetor = new Vector<>();
				vetor.add(Integer.toString(novo.getId()));
				vetor.add(novo.getNome());
				vetor.add(Integer.toString(novo.getIdade()));
				vetor.add(novo.getTelefone());
				vetor.add(novo.getCpf());
				vetor.add(novo.getSetor());
				model.addRow(vetor);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
  public JPanel painelInputFuncionarios() {
	  JPanel painelInput = new JPanel();
	  painelInput.setLayout(new GridLayout(4, 0));
	  
	  ArrayList<JTextField> listaInputs = new ArrayList<JTextField>();
	  String[] listaLables = new String[6];
	  listaLables[0] = "ID";
	  listaLables[1] = "Nome";
	  listaLables[2] = "Idade";
	  listaLables[3] = "Telefone";
	  listaLables[4] = "Cpf";
	  listaLables[5] = "Setor";
	  
	  for (int i = 0; i < listaLables.length; i++) {
		 JPanel painel = new JPanel();
		 painel.setLayout(null);
		 JLabel lable = new JLabel(listaLables[i]);
		lable.setBounds(20, 50,60,50);
		painel.add(lable);
		JTextField input = new JTextField();
		input.setBounds(70, 65, 200,20);
		listaInputs.add(input);
		painel.add(input);
		painelInput.add(painel);
	}
	  JPanel botoes = new JPanel();
	  botoes.setLayout(new FlowLayout());
	  
	  JButton botaoAdicionar = new JButton("Adicionar");
	  botaoAdicionar.setBackground(Color.green);
	  botaoAdicionar.setForeground(Color.black);
	  JButton botaoRemover = new JButton("Remover");
	  botaoRemover.setBackground(Color.red);
	  botaoRemover.setForeground(Color.black);
	  JButton botaoEditar = new JButton("Editar");
	  botaoEditar.setBackground(Color.blue);
	  botaoEditar.setForeground(Color.white);
	  
	  botoes.add(botaoAdicionar);
	  botoes.add(botaoEditar);
	  botoes.add(botaoRemover);
	  
	  
	  
	  JPanel completo = new JPanel();
	  completo.setLayout(new BorderLayout());
	  completo.add(painelInput, BorderLayout.CENTER);
	  completo.add(botoes, BorderLayout.SOUTH);
	  return completo;
  }
  
  
}
